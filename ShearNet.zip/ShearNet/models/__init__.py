#from .vgg16 import *
from .shearnet import *
#from .lenet import *
# Copyright (c) 2019, Adobe Inc. All rights reserved.
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike
# 4.0 International Public License. To view a copy of this license, visit
# https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.

import torch.nn as nn
from DWT_IDWT.DWT_IDWT_layer import *

class Downsample(nn.Module):
    def __init__(self):
        super(Downsample, self).__init__()
        self.dwt = DWT_2D_tiny()

    def forward(self, input):
        DWT = self.dwt(input)
       
        return DWT
