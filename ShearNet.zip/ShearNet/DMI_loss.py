# coding: utf8
import torch.nn as nn
import torch
from torch.autograd import Variable
import torch.nn.functional as F
import numpy as np 

class DMI_loss(nn.Module):
    def __init__(self,num_classes):
        super(DMI_loss, self).__init__() 
        self.num_classes = num_classes

    def forward(self,output,target):
        outputs = F.softmax(output, dim=1)
        targets = target.reshape(target.size(0), 1).cpu()
        #print (targets)
        y_onehot = torch.FloatTensor(target.size(0), self.num_classes).zero_()
        y_onehot.scatter_(1, targets, 1)
        y_onehot = y_onehot.transpose(0, 1).cuda()
        mat = y_onehot @ outputs
        """if torch.abs(torch.det(mat.float()))>1:
           print (y_onehot.shape)
           print (outputs.shape)
           print (torch.min(y_onehot))
           print (torch.max(y_onehot))
           print (torch.isnan(y_onehot))
           print (torch.isnan(y_onehot))
           print (torch.min(outputs))
           print (torch.max(outputs))
           print (torch.isnan(outputs))
           print (torch.isnan(outputs))
           print (torch.min(mat))
           print (torch.max(mat))
           print (torch.isnan(mat))
           print (torch.isnan(mat))
           print ('torch.abs(torch.det(mat.float()))-----------',torch.abs(torch.det(mat.float())))
           print ('L_dmi loss-----------',-1.0 * torch.log(torch.abs(torch.det(mat.float())) + 0.001))"""
        #return 1.0 * torch.log(1.0-torch.abs(torch.det(mat.float())) + 0.001)
        #print ("DMI_loss---------------",torch.abs(torch.det(mat.float())))

        """"abs_det = torch.abs(torch.det(mat.float()))
        if abs_det <= 10:
           abs_det = abs_det+ 10
        else:
           abs_det = abs_det

        return -1.0 * torch.log(abs_det)"""
        #aaa_loss = -1.0 * torch.log(torch.abs(torch.det(mat.float()))+10)
        #print (aaa_loss)
        #print (a)
        dmi_loss= -1.0 * torch.log(torch.abs(torch.det(mat.float()))+10)
        """diff_loss = torch.sum(torch.sub(f1,f2).pow(2), dim=(1,2,3))
        diff_loss = diff_loss.reshape(diff_loss.size(0), 1).cpu()
        diff_loss = torch.tensor(diff_loss).float()
        targets = torch.tensor(targets).float()
        media_v =torch.median(diff_loss)
        #max_di = torch.max(diff_loss)
        zeros_m = torch.zeros_like(diff_loss)
        diff_loss = torch.where(diff_loss>media_v*0.5,zeros_m,diff_loss)
        
        diff_loss =torch.mean(diff_loss)
        #print (diff_loss.shape,target.shape,diff_loss,dmi_loss)
        #print (a)"""
        return dmi_loss
        #return torch.mean(torch.pow((output - target), 2))
