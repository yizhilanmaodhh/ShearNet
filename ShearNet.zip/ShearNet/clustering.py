# Copyright (c) 2017-present, Facebook, Inc.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
import time
import cv2
from PIL import ImageFilter, ImageOps
import random

import faiss
import numpy as np
from PIL import Image
from PIL import ImageFile
from scipy.sparse import csr_matrix, find
import torch
import torch.utils.data as data
import torchvision.transforms as transforms
from skfuzzy.cluster import cmeans
import matplotlib.pyplot as plt
from  sklearn.cluster import AgglomerativeClustering
import scipy.signal as signal
from sklearn.cluster import SpectralClustering
from pyclust import KMedoids

from skimage.segmentation import slic,mark_boundaries
from scipy.cluster.vq import vq,whiten
from sklearn.cluster import KMeans
ImageFile.LOAD_TRUNCATED_IMAGES = True

__all__ = ['PIC', 'Kmeans', 'cluster_assign', 'arrange_clustering']


def pil_loader(path):
    """Loads an image.
    Args:
        path (string): path to image file
    Returns:
        Image
    """
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')


class ReassignedDataset(data.Dataset):
    """A dataset where the new images labels are given in argument.
    Args:
        image_indexes (list): list of data indexes
        pseudolabels (list): list of labels for each data
        dataset (list): list of tuples with paths to images
        transform (callable, optional): a function/transform that takes in
                                        an PIL image and returns a
                                        transformed version
    """
    
    def __init__(self, image_indexes, pseudolabels, dataset, transform=None):
        
        self.imgs = self.make_dataset(image_indexes, pseudolabels, dataset)
        self.transform = transform

    def make_dataset(self, image_indexes, pseudolabels, dataset):

        label_to_idx = {label: idx for idx, label in enumerate(set(pseudolabels))}
        images = []
        
    
        for j, idx in enumerate(image_indexes):
            
            path1 = dataset[idx][0]
            path2 = dataset[idx][1]
            pseudolabel = label_to_idx[pseudolabels[j]]
           
            images.append((path1,path2, pseudolabel))
        return images

    def __getitem__(self, index):
        """
        Args:
            index (int): index of data
        Returns:deepcluster
            tuple: (image, pseudolabel) where pseudolabel is the cluster of index datapoint
        """
       
        path1, path2,pseudolabel = self.imgs[index]
        img1 = pil_loader(path1)
        img2 = pil_loader(path2)
        
        if self.transform is not None:
            img1 = self.transform(img1)
            img2 = self.transform(img2)
            
        return img1,img2,pseudolabel

    def __len__(self):
        
        return len(self.imgs)


def preprocess_features(npdata, pca=50):
    """Preprocess an array of features.
    Args:
        npdata (np.array N * ndim): features to preprocess
        pca (int): dim of output
    Returns:
        np.array of dim N * pca: data PCA-reduced, whitened and L2-normalized
    """
   
    _, ndim = npdata.shape
    npdata =  npdata.astype('float32')

    # Apply PCA-whitening with Faiss
    mat = faiss.PCAMatrix (ndim, pca, eigen_power= 0) # -0.01, -1, -0.05 
    mat.train(npdata)
    assert mat.is_trained
    npdata = mat.apply_py(npdata)

    # L2 normalization
    row_sums = np.linalg.norm(npdata, axis=1)
    npdata = npdata / row_sums[:, np.newaxis]

    return npdata


def cluster_assign(images_lists, dataset):
    """Creates a dataset from clustering, with clusters as labels.
    Args:
        images_lists (list of list): for each cluster, the list of image indexes
                                    belonging to this cluster
        dataset (list): initial dataset
    Returns:d
        ReassignedDataset(torch.utils.data.Dataset): a dataset with clusters as
                                                     labels
    """
    
    assert images_lists is not None
    pseudolabels = []
    image_indexes = []
    for cluster, images in enumerate(images_lists):

        image_indexes.extend(images)
        pseudolabels.extend([cluster] * len(images))

    normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5],
                                     std=[0.5, 0.5, 0.5])
    
    t = transforms.Compose([transforms.ToTensor(),
                            normalize
                            ])

    return ReassignedDataset(image_indexes, pseudolabels, dataset, t)


def run_kmeans(label_image,root_save,x, I2,nmb_clusters, epoch,lr,nmb_cluster,verbose=False):
    """Runs kmeans on 1 GPU.
    Args:
        x: data
        nmb_clusters (int): number of clustersOctave卷积
    Returns:data=whiten(points
        list: ids of data in each cluster
    """
    i3 = label_image
    rows,cols = i3.shape
    x=whiten(x)
    x_temp = x 
    x = np.sum(x,1)
   
    estimator2 = KMeans(n_clusters=2)
    estimator2.fit(x_temp)
    I_2 = estimator2.labels_

    clus_centroid = 0
    other_name = "shearlet"
    calcu_changemap(root_save,x,"cf_"+other_name,epoch,lr,nmb_cluster,clus_centroid,0.00,0.00,i3)
    
    kappa0 = kappa(I_2.reshape(i3.shape), i3)
    kappa1 = kappa(np.abs(1-I_2.reshape(i3.shape)), i3)
    if kappa0>0:
       kappa_save = kappa0
    else:
       kappa_save = kappa1
    
    calcu_changemap(root_save,I_2,"cr2_"+other_name,epoch,lr,nmb_cluster,clus_centroid,kappa0,kappa1,i3)
    
   
    I_2 = I_2.reshape(rows*cols ,1)
    #----------------------end--------
    
    return [int(n[0]) for n in I_2],kappa_save

def kappa(TI, RI): 
    m,n = TI.shape
    
    TN = (RI==0) & (TI==0)
    TN = float(np.sum(TN==True))

    TP = (RI!=0) & (TI!=0)
    TP = float(np.sum(TP==True))

    FP = (RI==0) & (TI!=0)
    FP = float(np.sum(FP==True))

    FN = (RI!=0) & (TI==0)
    FN = float(np.sum(FN==True))

    Nc = FN + TP
    Nu = FP + TN
    OE = FP + FN;
    PRA = (TP+TN)/(m*n);
    PRE = ((TP+FP)*Nc+(FN+TN)*Nu)/(m*n)**2;
   
    KC = (PRA-PRE)/(1-PRE)
    print ('===evaluate====\n'
           'TN:{0} '
           'TP:{1} '
           'FP:{2} '
           'FN:{3} '
           'OE:{4} '
           'KC:{5} '.format(TN,TP,FP,FN,OE,KC))
    return KC

def calcu_changemap(root_save,B,temp,epoch,lr,nmb_cluster,clus_centroid,kappa0,kappa1,i1):
    rows,cols = i1.shape
    B_labels = B.reshape(i1.shape)
    max_x= np.max(B_labels)
    min_x= np.min(B_labels)
    B_labels = (B_labels - min_x)/(max_x-min_x)*255
    B_labels = Image.fromarray(B_labels.astype('uint8'))
    B_labels.save(root_save+"/%s_%s_%s_%s_%.4f_%.4f.png"%(temp,epoch,lr,nmb_cluster,kappa0,kappa1))

def arrange_clustering(images_lists):
    
    pseudolabels = []
    image_indexes = []
    for cluster, images in enumerate(images_lists):
        image_indexes.extend(images)
        pseudolabels.extend([cluster] * len(images))
        
    indexes = np.argsort(image_indexes)
 
    return np.asarray(pseudolabels)[indexes]


class Kmeans:
    
    def __init__(self, k):
        print ('Kmeans:__init__-------------------')
        self.k = k

    def cluster(self, root_label,root_save,data, I2, epoch,lr,nmb_cluster,verbose=False):
        """Performs k-means clustering.
            Args:
                x_data (np.array N * dim): data to cluster
                I2:the last cluster assignment
        """
        
        end = time.time()

        # cluster the data
        I_2,acc= run_kmeans(root_label,root_save,data, I2,self.k, epoch,lr,nmb_cluster,verbose)
        
        
        self.images_lists = [[] for i in range(nmb_cluster)]
         
        for i in range(len(data)):
           self.images_lists[I_2[i]].append(i)

        if verbose:
            print('k-means time: {0:.0f} s'.format(time.time() - end))

        return acc,I_2
