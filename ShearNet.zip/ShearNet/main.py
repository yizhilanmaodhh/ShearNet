# Copyright (c) 2017-present, Facebook, Inc.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
import argparse
import os
import pickle
import time

from multiprocessing import Process, Queue, Pool
from concurrent.futures import ThreadPoolExecutor, wait
import multiprocessing as mp
import threading

#import faiss
import numpy as np
from sklearn.metrics.cluster import normalized_mutual_info_score
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from PIL import Image
import matplotlib.pyplot as plt

import scipy.signal as signal
import clustering
import models
import mydataset
from util import AverageMeter, Logger, UnifLabelSampler
#from skimage import io,color

from torch.autograd import Variable
import torch.utils.data as Data
import torchvision
from torchvision import transforms
import torch.nn.functional as F
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import matplotlib.patheffects as PathEffects
import torch.optim.lr_scheduler as lr_scheduler
import matplotlib.cm as cm
import warnings
from torch.utils.data.dataloader import DataLoader
from DMI_loss import DMI_loss

import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import host_subplot
import adabound


#torch.cuda.current_device()
#torch.cuda._initialized = True

parser = argparse.ArgumentParser(description='PyTorch Implementation of DeepCluster')

parser.add_argument('data', metavar='DIR', help='path to dataset')
parser.add_argument('data_label', metavar='DIR_label', help='path to label')
parser.add_argument('data_save', metavar='DIR_save', help='path to savefile')
parser.add_argument('--arch', '-a', type=str, metavar='ARCH',
                    choices=['shearnet'], default='shearnet',
                    help='CNN architecture (default: lenet)')
parser.add_argument('--sobel', action='store_true', help='Sobel filtering')
parser.add_argument('--clustering', type=str, choices=['Kmeans', 'PIC'],
                    default='Kmeans', help='clustering algorithm (default: Kmeans)')

parser.add_argument('--nmb_cluster', '--k', type=int, default=15,
                    help='number of cluster for k-means (default: 2)')
parser.add_argument('--lr', default=0.01, type=float,
                    help='learning rate (default: 0.05)')
parser.add_argument('--wd', default=0.00001, type=float,
                    help='weight decay pow (default: -5)')

parser.add_argument('--reassign', type=float, default=1,
                    help="""how many epochs of training between two consecutive
                    reassignments of clusters (default: 1)""")
parser.add_argument('--workers', default=8, type=int,
                    help='number of data loading workers (default: 4)')
parser.add_argument('--epochs', type=int, default=15,
                    help='number of total epochs to run (default: 200)')
parser.add_argument('--start_epoch', default=0, type=int,
                    help='manual epoch number (useful on restarts) (default: 0)')
parser.add_argument('--batch', default=256, type=int,
                    help='mini-batch size (default: 36)')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum (default: 0.9)')
parser.add_argument('--resume', default='/home/donghuihui/change_detection/deepcluster-master-multiscale2/test/exp/checkpoint3.pth.tar', type=str, metavar='PATH',
                    help='path to checkpoint (default: None)')
parser.add_argument('--checkpoints', type=int, default=200,
                    help='how many iterations between two checkpoints (default: 25000)')
parser.add_argument('--seed', type=int, default=10, help='random seed (default: 10)')
parser.add_argument('--exp', type=str, default='exp', help='path to exp folder')
parser.add_argument('--verbose', action='store_true', help='chatty')

def main():
    start_main = time.time()
    
    global args
    args = parser.parse_args()

    # fix random seeds
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)

    #generate sample
    DIR1="/data_set/Yellow River/Yellow River IV-SAR"
   
    i1 = np.array(Image.open(DIR1+"/im1.bmp").convert('L'))
    i2 = np.array(Image.open(DIR1+"/im2.bmp").convert('L'))
    
    neibor_size = 7
    #-------------------------------image pad--------------------
    add_size = neibor_size//2
   
    rows_array1 = i1[:,0:add_size]
    rows_array2 = i2[:,0:add_size]

    i1 = np.hstack((rows_array1,i1,rows_array1))
    i2 = np.hstack((rows_array2,i2,rows_array2))
   
    cols_array1 = i1[0:add_size,:]
    cols_array2 = i2[0:add_size,:]
    
    i1 = np.vstack((cols_array1,i1,cols_array1))
    i2 = np.vstack((cols_array2,i2,cols_array2))
    #--------------------end--------------------------

    generate_sample(i1,i2,neibor_size,args.data)

    # CNN
    if args.verbose:
        print('Architecture: {}'.format(args.arch))
    model = models.__dict__[args.arch](sobel=None,bn=True, out=args.nmb_cluster) #args.sobel
    fd = int(model.top_layer.weight.size()[1])
    model.top_layer = None
     
    model.be_feature1 = model.be_feature1
    model.features = model.features
    
    model.be_feature1 = torch.nn.DataParallel(model.be_feature1)
    model.features = torch.nn.DataParallel(model.features)
    
    model.cuda()
    
    cudnn.benchmark = True

    # create optimizer
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    # define loss function
    criterion = DMI_loss(args.nmb_cluster).cuda() #args.nmb_cluster
    
    # optionally resume from a checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            print("=> loading checkpoint '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # remove top_layer parameters from checkpoint
            for key in list(checkpoint['state_dict']):
                if 'top_layer' in key:
                    del checkpoint['state_dict'][key]
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            print("=> loaded checkpoint '{}' (epoch {})"
                  .format(args.resume, checkpoint['epoch']))
        else:
            print("=> no checkpoint found at '{}'".format(args.resume))

    # creating checkpoint repo
    exp_check = os.path.join(args.exp, 'checkpoints')
    if not os.path.isdir(exp_check):
        os.makedirs(exp_check)

    # creating cluster assignments log
    cluster_log = Logger(os.path.join(args.exp, 'clusters'))

    # preprocessing of data
    normalize = transforms.Normalize(mean=[0.5,0.5,0.5],
                                     std=[0.5,0.5,0.5])
   
    tra = [transforms.ToTensor(),
           normalize
          ]

    # load the reference
    label_map = np.array(Image.open(args.data_label+"/ref.bmp").convert('L'))
    end = time.time()
    
    dataset=mydataset.MyDataset(args.data, label_map,transform=transforms.Compose(tra))

    if args.verbose: print('Load dataset: {0:.2f} s'.format(time.time() - end))
    dataloader = DataLoader(dataset,       #torch.utils.data.
                            batch_size=args.batch,#args.batch
                            num_workers=args.workers,
                            pin_memory=True
                            )
  
    # clustering algorithm to use
    deepcluster = clustering.__dict__[args.clustering](args.nmb_cluster)

    predicted_result = np.zeros((len(dataset),1))
                          
    eval_loss_list = []
    eval_acc_list = []
    I_2 = np.zeros((len(dataset),1))
    
    # training convnet with DeepCluster
    lr_init = optimizer.param_groups[0]['lr']
    
    for epoch in range(args.start_epoch, args.epochs):
        end = time.time()
       
        if epoch == 0:
          # remove head
          model.top_layer = None
          model.classifier = nn.Sequential(*list(model.classifier.children())[:-1])
         
          # get the features for the whole datasetimages_lists_accurate
          features = compute_features(dataloader,model, len(dataset))
          
          # cluster the features   nmb_cluster_list[epoch] args.nmb_cluster
          acc, I_2 = deepcluster.cluster(label_map,args.data_save,features,I_2,epoch,args.lr,args.nmb_cluster,verbose=args.verbose)
             
          clustering_loss = 0.0

          #assign pseudo-labels
          train_dataset = clustering.cluster_assign(deepcluster.images_lists,
                                                  dataset.imgs) 
          
          sampler = UnifLabelSampler(int(args.reassign * len(train_dataset)),
                                  deepcluster.images_lists)

          train_dataloader = torch.utils.data.DataLoader(
              train_dataset,
              batch_size=args.batch,
              shuffle=False,
              num_workers=args.workers,
              sampler=sampler,
              pin_memory=True,
          )
          
          # set last fully connected layer
          mlp = list(model.classifier.children())
          mlp.append(nn.ReLU(inplace=True).cuda())
          model.classifier = nn.Sequential(*mlp)
          model.top_layer = nn.Linear(fd, len(deepcluster.images_lists))
          model.top_layer.weight.data.normal_(0, 0.01)
          model.top_layer.bias.data.zero_()
          model.top_layer.cuda()
       
        # train network with clusters as pseudo-labels
        end = time.time()
        loss = train(train_dataloader, model, criterion, optimizer, epoch)

        # save test result...
        eval_loss_list.append(loss)
        eval_acc_list.append(acc)

        #loss_reassign = loss
        predicted_result = test(dataloader, model, len(dataset),epoch)
        acc = calcu_changemap_predict(label_map,args.data_save,predicted_result,"p_",epoch,args.lr,args.reassign)

        if args.verbose:
            print('###### Epoch [{0}] ###### \n'
                  'Time: {1:.3f} s\n'
                  'Clustering loss: {2:.3f} \n'
                  'ConvNet loss: {3:.3f}'
                  .format(epoch,time.time() - end, clustering_loss, loss))
            try:
                nmi = normalized_mutual_info_score(
                    clustering.arrange_clustering(deepcluster.images_lists),
                    clustering.arrange_clustering(cluster_log.data[-1])
                )
                #print (cluster_log.data)
                print('NMI against previous assignment: {0:.3f}'.format(nmi))
            except IndexError:
                pass
            print('####################### \n')
        # save running checkpoint
        torch.save({'epoch': epoch + 1,
                    'arch': args.arch,
                    'state_dict': model.state_dict(),
                    'optimizer' : optimizer.state_dict()},
                   os.path.join(args.exp, 'checkpoint.pth.tar'))

        # save cluster assignments
        cluster_log.log(deepcluster.images_lists)
        # when loss remains unchange for 20 epoch, stop iterations
        """if loss == loss_last:
           loss_equal = loss_equal + 1 
        if loss_equal >=20:
            break   """
     
    end_main = time.time()
    print ('Running time:%s seconds'%(end_main-start_main))

    plot_acc_loss(args.data_save,eval_loss_list, eval_acc_list)
    plot_loss(args.data_save,eval_loss_list)
  
    np.save(args.data_save+'/loss.npy',eval_loss_list) 
    np.save(args.data_save+'/accuracy.npy',eval_acc_list) 

def generate_sample(i1,i2,neibor_size,DIR2):
  
    rows,cols = i1.shape
    add_size = neibor_size//2
    rows = rows-neibor_size+1
    cols = cols-neibor_size+1
    
    n = 0
    train_x_i1 = np.zeros((1,neibor_size*neibor_size))
    train_x_i2 = np.zeros((1,neibor_size*neibor_size))
   
    neibor_zeros = np.zeros((neibor_size,neibor_size))
    #--------------------------------------------------
    for i in range (rows):
      for j in range (cols):
          neibor1 = i1[i:neibor_size+i,j:neibor_size+j]
          neibor2 = i2[i:neibor_size+i,j:neibor_size+j]

          patch1 = Image.fromarray(neibor1.astype(np.uint8))
          patch2 = Image.fromarray(neibor2.astype(np.uint8))
      
          patch1.save(args.data+"/i1_%s/%s_%04d.jpg" % (neibor_size,"c", n))
          patch2.save(args.data+"/i2_%s/%s_%04d.jpg" % (neibor_size,"c", n))
          n = n + 1
    
def plot_acc_loss(root_save,loss, acc):
    host = host_subplot(111)  # row=1 col=1 first pic
    plt.subplots_adjust(right=0.8)  # ajust the right boundary of the plot window
    par1 = host.twinx()   # 共享x轴

    # set labels
    host.set_xlabel("Epoch")
    host.set_ylabel("Loss")
    par1.set_ylabel("Accuracy(Kappa)")
 
    # plot curves
    p1, = host.plot(range(len(loss)), loss, label="Loss")
    p2, = par1.plot(range(len(acc)), acc, label="Accuracy")
 
    # set location of the legend,
    # 1->rightup corner, 2->leftup corner, 3->leftdown corner
    # 4->rightdown corner, 5->rightmid ...
    host.legend(loc=5)
 
    # set label color
    host.axis["left"].label.set_color(p1.get_color())
    par1.axis["right"].label.set_color(p2.get_color())
 
    #plt.tick_params(labelsize=16)
    #par1.tick_params(labelsize=16)

    # set the range of x axis of host and y axis of par1
    # host.set_xlim([-200, 5200])
    # par1.set_ylim([-0.1, 1.1])
    plt.grid()  # 生成网格
    plt.draw()
    plt.savefig(root_save+"/plt_acc_loss.eps")
    plt.savefig(root_save+"/plt_acc_loss.png")
    #plt.show()
def plot_loss(root_save,loss):
    #output.save("/home/donghuihui/change_detection/result/Sriver/cluster_output_%.4f_%.4f.png" % (kappa0,kappa1))    
    host = host_subplot(111)  # row=1 col=1 first pic
    plt.subplots_adjust(right=0.8)  # ajust the right boundary of the plot window
    #par1 = host.twinx()   # 共享x轴

    #设置图例并且设置图例的字体及大小
    font1 = {'family' : 'Times New Roman',
    'weight' : 'normal',
    'size'   : 16,
    }
    # set labels
    host.set_xlabel("Epoch",font1)
    host.set_ylabel("Loss",font1)
    #par1.set_ylabel("Accuracy(Kappa)")
 
    # plot curves
    p1, = host.plot(range(len(loss)), loss)
    #p2, = par1.plot(range(len(acc)), acc, label="accuracy")
 
    # set location of the legend,
    # 1->rightup corner, 2->leftup corner, 3->leftdown corner
    # 4->rightdown corner, 5->rightmidroot_save+"/ ...
    host.legend(loc=5,prop=font1)
 
    # set label color
    host.axis["left"].label.set_color(p1.get_color())
    #par1.axis["right"].label.set_color(p2.get_color())
 
    plt.tick_params(labelsize=16)
    # set the range of x axis of host and y axis of par1
    # host.set_xlim([-200, 5200])
    # par1.set_ylim([-0.1, 1.1])
    plt.grid()  # 生成网格
    plt.draw()
    plt.savefig(root_save+"/plt_loss.eps")
    plt.savefig(root_save+"/plt_loss.png")
    
    #plt.show()farmlandD
def adjust_learning_rate(optimizer, epoch,lr):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    #lr = args.lr * (0.1 ** (epoch // 50))
    #lr = args.lr +  (0.001 ** (epoch // 2))
    #lr = args.lr * (1 / (1 + 0.001 * epoch))
    #lr *= (0.1 ** (epoch // 20)) #lr间隔20
    #lr = 0.2 **(epoch+3)
    if epoch <5:
      lr = 0.00001
    else:
      lr = 0.000001
    
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
   
def calcu_changemap(images_labels_lists): 
    print ('calcu_changemap-------------------')
    i1 = np.array(Image.open(".../Yellow River/Yellow River II-SAR/YR-II-ref.bmp").convert('L'))
    rows,cols = i1.shape
    pseudolabels = np.zeros((rows*cols,1))
    
    for cluster, images in enumerate(images_labels_lists):
        #images = np.array(images)
        for i in range(len(images)):
            pseudolabels[images[i],:] = cluster 
    print (pseudolabels.shape)
    pseudolabels = pseudolabels.reshape(i1.shape)

    print ('======================evaluate predicted===============')
    kappa0 = kappa(pseudolabels, i1/255)
    kappa1 = kappa(np.abs(1-pseudolabels), i1/255)
    #print (B_labels)
    output = pseudolabels
    print (np.max(output))
    print (np.min(output))
    output = output.reshape(i1.shape)
    max_x= np.max(output)
    min_x= np.min(output)
    output = (output - min_x)/(max_x-min_x)*255
    output = Image.fromarray(output.astype(np.uint8))
    output.save(".../result/Sriver/cluster_output_%.4f_%.4f.png" % (kappa0,kappa1))    
    #output.save("/home/donghuihui/change_detection/deepcluster-master-multiscale2/result_save/cluster_output.bmp")    

def kappa(TI, RI): #testData表示要计算的数据，k表示数据矩阵的是k*k的
    m,n = TI.shape
    
    TN = (RI==0) & (TI==0)
    TN = float(np.sum(TN==True))

    TP = (RI!=0) & (TI!=0)
    TP = float(np.sum(TP==True))

    FP = (RI==0) & (TI!=0)
    FP = float(np.sum(FP==True))

    FN = (RI!=0) & (TI==0)
    FN = float(np.sum(FN==True))

    Nc = FN + TP
    Nu = FP + TN
    OE = FP + FN;
    PRA = (TP+TN)/(m*n);
    PRE = ((TP+FP)*Nc+(FN+TN)*Nu)/(m*n)**2;

    KC = (PRA-PRE)/(1-PRE)
    print ('===evaluate====\n'
           'TN:{0} '
           'TP:{1} '
           'FP:{2} '
           'FN:{3} '
           'OE:{4} '
           'KC:{5} '.format(TN,TP,FP,FN,OE,KC))  
    return KC

def train(loader, model, crit1,opt,epoch):
    """Training of the CNN.
        Args:
            loader (torch.utils.data.DataLoader): Data loader
            model (nn.Module): CNN
            crit (torch.nn): loss
            opt (torch.optim.SGD): optimizer for every parameters with True
                                   requires_grad in model except top layer
            epoch (int)
    """
    batch_time = AverageMeter()
    losses = AverageMeter()
    data_time = AverageMeter()
    forward_time = AverageMeter()
    backward_time = AverageMeter()

    # switch to train mode
    model.train()

    end = time.time()
    for i, (input_tensor1,input_tensor2,target) in enumerate(loader):
        data_time.update(time.time() - end)
        
        # save checkpoint
        n = len(loader) * epoch + i
        if n % args.checkpoints == 0:
            path = os.path.join(
                args.exp,
                'checkpoints',
                'checkpoint_' + str(n / args.checkpoints) + '.pth.tar',
            )
            if args.verbose:
                print('Save checkpoint at: {0}'.format(path))
            torch.save({
                'epoch': epoch + 1,
                'arch': args.arch,
                'state_dict': model.state_dict(),
                'optimizer' : opt.state_dict()
            }, path)

        target = target.cuda()
        input_var1 = torch.autograd.Variable(input_tensor1.cuda())
        input_var2 = torch.autograd.Variable(input_tensor2.cuda())
       
        target_var = torch.autograd.Variable(target)

        output = model(input_var1,input_var2)

        loss = crit1(output, target_var) 
        losses.update(loss.item(), input_tensor1.size(0))
        
        # compute gradient and do SGD step
        opt.zero_grad()

        loss.backward()
        opt.step()
        
        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()
        
        if args.verbose and (i % 200) == 0:
            #print (model.attn1.gamma.mean().item())
            print('Epoch: [{0}][{1}/{2}]\t'
                  'Time: {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Data: {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'Loss: {loss.val:.4f} ({loss.avg:.4f})'
                  .format(epoch, i, len(loader), batch_time=batch_time,
                          data_time=data_time, loss=losses))
   
    return losses.avg

def compute_features(dataloader, model, N):
    if args.verbose:
        print('Compute features')
    batch_time = AverageMeter()
    end = time.time()
    model.eval()
    total_feature = []
    # discard the label information in the dataloader
    for i, (input_tensor1,input_tensor2,target) in enumerate(dataloader):
        
        input_var1 = torch.autograd.Variable(input_tensor1.cuda(),volatile=True)
        input_var2 = torch.autograd.Variable(input_tensor2.cuda(),volatile=True)
       
        aux = model(input_var1,input_var2).data.cpu().numpy()
        
        if i == 0:
            features = np.zeros((N, aux.shape[1])).astype('float32')

        if i < len(dataloader) - 1:
            features[i * args.batch: (i + 1) * args.batch] = aux.astype('float32')
        else:
            # special treatment for final batch
            features[i * args.batch:] = aux.astype('float32')

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if args.verbose and (i % 20) == 0:
            print('{0} // {1}\t'
                  'Time: {batch_time.val:.3f} ({batch_time.avg:.3f})'
                  .format(i, len(dataloader), batch_time=batch_time))  

    return features

def calcu_changemap_predict(i1, root_save,B,temp,epoch,lr,nmb_cluster):
    rows,cols = i1.shape
    
    B_labels = B.reshape(i1.shape)

    kappa0 = kappa(B_labels, i1/255)
    kappa1 = kappa(np.abs(1-B_labels), i1/255)

    max_x= np.max(B_labels)
    min_x= np.min(B_labels)
    B_labels = (B_labels - min_x)/(max_x-min_x)*255
    
    B_labels = Image.fromarray(B_labels.astype('uint8'))
    
    B_labels.save(root_save+"/%s_%s_%s_%s_%.4f_%.4f.png" % (temp,epoch,lr,nmb_cluster,kappa0,kappa1))    

    if kappa0 > 0:
       kappa_save = kappa0
    else:
       kappa_save = kappa1
   
    return  kappa_save

def test(dataloader, model, N,epoch):
    batch_time = AverageMeter()
    end = time.time()
    model.eval()
    total_pred_label = []
    total_target = []
    total_feature = []
    # discard the label information in the dataloader
    for i, (input_tensor1,input_tensor2,target) in enumerate(dataloader):
        input_var1 = torch.autograd.Variable(input_tensor1.cuda(),volatile=True)
        input_var2 = torch.autograd.Variable(input_tensor2.cuda(),volatile=True)
        
        aux = model(input_var1,input_var2).data.cpu().numpy()
        pred  = np.argmax(aux,1)
        
        if i == 0:
            features = np.zeros((N))#.astype('float32')
            
        if i < len(dataloader) - 1:
            features[i * args.batch: (i + 1) * args.batch] = pred#.astype('float32')
        else:
            # special treatment for final batch
            features[i * args.batch:] = pred#.astype('float32')

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()
   
    return features

if __name__ == '__main__':
   
    warnings.filterwarnings('ignore')
    main()
