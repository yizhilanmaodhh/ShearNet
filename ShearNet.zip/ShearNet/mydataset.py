from torchvision import transforms, utils
from torch.utils.data import Dataset
from torch.utils.data.dataloader import DataLoader
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np 
import os

def default_loader(path):
    return Image.open(path).convert('RGB')
    #return Image.open(path).convert('L')
 
 
class MyDataset(Dataset):
    def __init__(self, root, i3,transform=None, target_transform=None,loader=default_loader):
        
        rows,cols = i3.shape
        i3 = i3/255
        labels = i3.reshape(rows*cols,1)
        imgs = []
        for i in range(0,rows*cols): 
            img_file1 = os.path.join(root+"/i1_7/","c_%04d.jpg"%i) 
            img_file2 = os.path.join(root+"/i2_7/","c_%04d.jpg"%i)
            
            imgs.append((img_file1,img_file2,labels[i,0]))
        self.imgs = imgs
        self.transform = transform
        self.target_transform = target_transform
        self.loader = loader
 
    def __getitem__(self, index):
        fn1,fn2, label = self.imgs[index]
        img1 = self.loader(fn1)
        img2 = self.loader(fn2)
        
        if self.transform is not None:
            img1 = self.transform(img1)
            img2 = self.transform(img2)
            
        return img1,img2,label
 
    def __len__(self):
        return len(self.imgs)
    
